
var express = require('express');

var router1 = express.Router();
var router2 = express.Router();
var router3 = express.Router();
var router4 = express.Router();
var router5 = express.Router();
var router6 = express.Router();

router1.get('/',(req, res) => {
    res.render('home/views/index');
});

router2.get('/',(req, res) => {
    res.render('home/views/create');
});

router2.post('/', (req, res) => {
    var db = require('../../lib/database')();
    db.query(`INSERT INTO \`pokemontb\` (\`name\`, \`type\`,\`height\`,\`weight\`)  VALUES ("${req.body.name}", "${req.body.type}",${req.body.height},${req.body.weight})`, (err, results, fields) => {
        if (err) console.log(err);
        res.redirect('/index');
    });
});

router3.get('/', (req, res) => {
    var db = require('../../lib/database')();
    
	db.query('SELECT * FROM pokemontb WHERE status = true', function (err, results, fields) {
        if (err) return res.send(err);
        render(results);
    });
   
   function render(users) {
        res.render('home/views/view', { users: users });
    }
});

router4.get('/',(req, res) => {
    res.render('home/views/search');
 
});
router6.post('/', (req, res) => {
	 var db = require('../../lib/database')();
    
	db.query(`SELECT * FROM pokemontb WHERE number=${req.body.ID}`, function (err, results, fields) {
        if (err) return res.send(err);
        render(results);
    });
   
   function render(users) {
        res.render('home/views/update', { users: users });
	
    }
      
		
});

router1.post('/', (req, res) => {
	    var db = require('../../lib/database')();
	  db.query(`UPDATE pokemontb SET name="${req.body.name}",type="${req.body.type}",height=${req.body.height},weight=${req.body.weight} WHERE number=${req.body.ID}`, (err, results, fields) => {
        if (err) console.log(err);
        res.redirect('/index');
    });
});


router5.get('/',(req, res) => {
    res.render('home/views/delete');
});
router5.post('/', (req, res) => {
    var db = require('../../lib/database')();
    db.query(`UPDATE pokemontb SET status=false WHERE number=${req.body.ID}`, (err, results, fields) => {
        if (err) console.log(err);
        res.redirect('/index');
    });
});






exports.index = router1;
exports.create = router2;
exports.view = router3;
exports.search = router4;
exports.delete = router5;
exports.update = router6;