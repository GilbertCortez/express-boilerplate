DATABASE DESIGN

	Database Name: pokemondb
		Table Name: pokemontb
			Columns & their definitions: 
				-number (int,primary key, auto_increment,not null)
				-name (varchar(44), not null)
				-type(varchar(44), not null)
				-height(double, not null)
				-weight(double, not null)
				-status(boolean, deafault true)
				

NOTE: For suggestion and comments, please contact me. :) 